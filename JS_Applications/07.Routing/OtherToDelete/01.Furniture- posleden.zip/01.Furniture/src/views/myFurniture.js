export async function myPage (ctx) {
    console.log('my furniture page')
    }