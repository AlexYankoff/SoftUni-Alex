// SET THE HOST BELOW
import page from '../node_modules/page/page.mjs';
import { render } from '../node_modules/lit-html/lit-html.js'

import { dashboardPage } from './views/dashboard.js'
import {myPage} from './views/myFurniture.js'
import {detailsPage} from './views/details.js'
import {createPage} from './views/create.js'
import {editPage} from './views/edit.js'
import {registerPage} from './views/register.js'
import {loginPage} from './views/login.js'

import * as api from './api/data.js';


window.api = api;

const main = document.querySelector('.container')// SET IT

//routing table - изпълнява дадената ф-я и й подава context
page('/', renderMiddleware, dashboardPage); //view Controller
page('/my-furniture', renderMiddleware, myPage);
page('/details/:id', renderMiddleware, detailsPage);// в контекста имаме и id
page('/create', renderMiddleware, createPage); 
page('/edit/:id', renderMiddleware,editPage);
page('/register', renderMiddleware,registerPage);
page('/login', renderMiddleware, loginPage);

page.start();

function renderMiddleware(ctx, next) {
    ctx.render = (ctx) => render(ctx, main)
    next()
}



