export async function detailsPage (ctx) {
    console.log('details page', ctx.params.id)
    }