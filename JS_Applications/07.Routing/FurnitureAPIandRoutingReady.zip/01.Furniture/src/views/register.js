export async function registerPage (ctx) {
    console.log('register page')
    }