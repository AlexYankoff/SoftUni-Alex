const info = false


const a = info ? 'Da' : 'Ne'
console.log(a)

info ? console.log("Ehaa") : console.log('neee')