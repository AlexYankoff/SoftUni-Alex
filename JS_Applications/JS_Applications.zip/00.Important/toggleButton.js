infoDiv.style.display = infoDiv.style.display !='block' ? 'block' : 'none';
event.target.textContent = event.target.textContent == "Show status code" ? "Hide status code" : "Show status code"


//Първо му сменяме състоянието, а после текста на бутона